package com.example.five;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.style.LineHeightSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    //SharedPreferences文件名
    private final static String SharedPreferencesFileName="config";

    //键
    private final static String Key_xuehao="xuehao";//学号
    private final static String Key_xingming="xingming";//姓名

    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //获得SharedPreferences实例
        preferences=getSharedPreferences(SharedPreferencesFileName,
                MODE_PRIVATE);
        editor=preferences.edit();
        Button btnWrite=(Button)findViewById(R.id.write);
        Button btnRead=(Button)findViewById(R.id.read);
        btnWrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText xuehao,xingming;
                xuehao = findViewById(R.id.xuehao);
                xingming = findViewById(R.id.xingming);
                //写入键值对
                editor.putString(Key_xuehao,xuehao.getText().toString());
                editor.putString(Key_xingming, xingming.getText().toString());

                //提交修改，此处换成commit()也可以
                editor.apply();
            }
        });

        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView shuju = findViewById(R.id.shuju);
                String xuehao = preferences.getString(Key_xuehao, null);
                String xingming = preferences.getString(Key_xingming, null);
                if (xuehao != null && xingming != null)
                  shuju.setText("学生姓名："+xingming+"\n"+"学生学号："+xuehao);
                else
                    Toast.makeText(MainActivity.this, "无数据", Toast.LENGTH_LONG).show();
            }
        });
        Button xieru = findViewById(R.id.xieruwenjian);
        xieru.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OutputStream out = null;
                try{
                    EditText xuehao = findViewById(R.id.xuehao);
                    EditText xingming = findViewById(R.id.xingming);
                    FileOutputStream F= openFileOutput("XUESHENG",MODE_PRIVATE);      //创建文件以及设置模式
                    out = new BufferedOutputStream(F);
                    String content = "学生姓名："+xingming.getText().toString()+"\n"+"学生学号："+xuehao.getText().toString();

                    try{
                        out.write(content.getBytes(StandardCharsets.UTF_8));
                    } finally {
                        if(out!=null){
                            out.close();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        Button lianxiren = findViewById(R.id.lianxiren);
        lianxiren.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = ContactsContract.Contacts.CONTENT_URI;      //这里将地址提出来  并导入Uri的包
                Cursor cursor=getContentResolver().query(uri,null,null,null,null);
                while ((cursor.moveToNext())){
                    String msg;
                    String id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                    msg = "ID为:"+id;
                    String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                    msg = msg+" 姓名为:"+name;
                    //phone
                    Cursor phoneNumbers=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,ContactsContract.CommonDataKinds.Phone.CONTACT_ID +"="+id,null,null);
                    while(phoneNumbers.moveToNext()){
                        String phoneNumber=phoneNumbers.getString(phoneNumbers.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        msg=msg+" 手机号为:"+phoneNumber;
                    }
                    //email
                    Cursor emails=getContentResolver().query(ContactsContract.CommonDataKinds.Email.CONTENT_URI,null,ContactsContract.CommonDataKinds.Email.CONTACT_ID +"="+id,null,null);
                    while(emails.moveToNext()){
                        String email=emails.getString(emails.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA));
                        msg=msg+" 电子邮件地址为:"+email;
                    }
                    TextView shuchu = findViewById(R.id.shuchu);
                    shuchu.setText(msg);
                }
            }
        });
                }

            }


